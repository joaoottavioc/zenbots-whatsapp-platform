import json
import logging
import boto3
import os

logger = logging.getLogger()
logger.setLevel(logging.INFO)

rds = boto3.client("rds")
INSTANCE_ID = os.environ["RDS_INSTANCE_ID"]


def get_instance_status():
    resp = rds.describe_db_instances(DBInstanceIdentifier=INSTANCE_ID)
    return resp["DBInstances"][0]["DBInstanceStatus"]


def handler(event, context):
    action = event.get("action")
    if action not in ("start", "stop"):
        raise ValueError(f"Invalid action: {action}. Must be 'start' or 'stop'.")

    status = get_instance_status()
    logger.info(f"RDS {INSTANCE_ID} current status: {status}, requested action: {action}")

    if action == "stop":
        if status == "stopped":
            logger.info("Instance already stopped, skipping.")
            return {"status": "already_stopped"}
        if status != "available":
            logger.warning(f"Cannot stop instance in state '{status}', skipping.")
            return {"status": "skipped", "reason": f"instance_state_{status}"}
        rds.stop_db_instance(DBInstanceIdentifier=INSTANCE_ID)
        logger.info("Stop command sent successfully.")
        return {"status": "stopping"}

    if action == "start":
        if status == "available":
            logger.info("Instance already available, skipping.")
            return {"status": "already_available"}
        if status != "stopped":
            logger.warning(f"Cannot start instance in state '{status}', skipping.")
            return {"status": "skipped", "reason": f"instance_state_{status}"}
        rds.start_db_instance(DBInstanceIdentifier=INSTANCE_ID)
        logger.info("Start command sent successfully.")
        return {"status": "starting"}
